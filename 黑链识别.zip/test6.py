#!/usr/bin/python
# -*- coding: utf-8 -*-
# @Time    : 2022/10/20 00:09
# @Author  : AA8j
# @Site    :
# @File    : test4.py
# @Software: PyCharm
# @Blog    : https://blog.csdn.net/qq_44874645
import re
import threading
import time
from html import unescape

import requests
from pyexcel_xls import get_data
from pyexcel_xls import save_data
from collections import OrderedDict


def get(url, headers, data, time):
    try:
        url = 'http://' + url
        response = req.get(url, headers=headers, params=data, timeout=time)
        # 获得响应对象，allow_redirects=False为不启动重定向（默认开启）
        response.encoding = 'utf-8'
        # 编码
        return response, url
    except Exception as e:
        return False


def post(url, headers, data, time):
    response = req.post(url, headers=headers, data=data, timeout=time)
    response.encoding = 'utf-8'
    return response


def get_token(html):
    pattern = re.compile(r"<input type='hidden' name='user_token' value='(.*?)' />")
    token = pattern.search(html).group(1)
    return token


def get_html(u):
    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'}
    # 随机UA头
    TIMEOUT = 3
    # 超时时间
    URL = u

    # 访问网站获得token
    DATA = {}
    # TOKEN = get_token(post(URL, HEADERS, DATA, TIMEOUT).text)

    # 提交参数
    # DATA = {'username': 'admin', 'password': 'pwd', 'Login': 'Login', 'user_token': TOKEN}
    Response, url = get(URL, HEADERS, DATA, TIMEOUT)
    # Response = get(URL, HEADERS, DATA, TIMEOUT)
    HTML = Response.text

    code = Response.status_code
    length = len(HTML)
    try:
        title = re.findall('<title>(.+)</title>', HTML)[0]
        if '&#' in title:
            # 实体编码解码
            title = unescape(title)
            HTML = unescape(HTML)
    except Exception as e:
        title = 'NULL'
    return url, HTML, code, length, title


def count(html, rules):
    hit_count = 0
    hit_list = []
    html = re.sub(r'\n', '', html)
    for k in rules:
        if k in html:
            hit_count += 1
            hit_list.append(k)
    return hit_count, hit_list


def go_thread(i):
    u = i
    try:
        url, HTML, code, length, title = get_html(u)
        hit_count, hit_list = count(HTML, rules_words_list)
    except Exception as e:
        url, code, length, hit_count, hit_list, title = '无法访问', 'NULL', 0, 0, 'NULL', 'NULL'

    with lock:  # 同步锁
        # f1.write(f'{u}, {code}, {length}, {title}, {hit_count}, {hit_list}\n')
        global count_n
        print(f'{count_n}/{targets_length}', end='：')
        print(u, url, code, length, hit_list, hit_count, title)
        row1 = [u, url, code, length, str(hit_list), hit_count, title]
        global rows_list
        rows_list.append(row1)
        count_n += 1


if __name__ == '__main__':
    req = requests.session()
    # 维持会话

    rules_words_list = []
    with open('rules.txt', 'r', encoding='utf-8') as fr:
        for l in fr:
            rules_words_list.append(l.split('\n')[0])

    targets = []
    with open('targets.txt', 'r') as t:
        for i in t:
            targets.append(i.split('\n')[0])

    # 创建表
    data = OrderedDict()
    # Sheet1
    sheet_1 = []
    # with open('result.txt', 'w', encoding='utf-8') as f1:
    # f1.write(f'url, code, length, title, 命中规则次数, 命中规则\n')
    row1 = ['domain', 'url', 'code', 'length', '命中规则', '命中次数', 'title']
    sheet_1.append(row1)

    sem = threading.Semaphore(50)
    # 线程的数量为10个
    lock = threading.Lock()

    targets_length = len(targets)
    count_n = 1
    rows_list = []

    thread_list = []
    for i in targets:
        thread_list.append(threading.Thread(target=go_thread, args=(i,)))

    for t in thread_list:
        t.start()

    for t in thread_list:
        t.join()
    print('等待所有线程结束...', end='')
    for r in rows_list:
        sheet_1.append(r)

    data.update({'Sheet1': sheet_1})
    save_data('result.xls', data)
    print('Done!')
